﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using MvcMovieStoreApp.Models;

namespace MvcMovieStoreApp.Data
{
    public class MvcMovieStoreAppContext : DbContext
    {
        public MvcMovieStoreAppContext (DbContextOptions<MvcMovieStoreAppContext> options)
            : base(options)
        {
        }

        public DbSet<MvcMovieStoreApp.Models.Movie> Movie { get; set; }
    }
}
